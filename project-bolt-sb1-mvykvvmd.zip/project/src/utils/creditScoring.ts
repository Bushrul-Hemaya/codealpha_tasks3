import { FinancialData, CreditScore } from '../types';

export function calculateCreditScore(data: FinancialData): CreditScore {
  // Weight factors (total = 100)
  const weights = {
    income: 20,
    employmentYears: 15,
    creditUtilization: 25,
    paymentHistory: 25,
    existingLoans: 5,
    creditHistory: 10,
  };

  // Calculate individual scores
  const incomeScore = Math.min((data.income / 100000) * weights.income, weights.income);
  const employmentScore = Math.min((data.employmentYears / 10) * weights.employmentYears, weights.employmentYears);
  const utilizationScore = ((100 - data.creditUtilization) / 100) * weights.creditUtilization;
  const paymentScore = (data.paymentHistory / 100) * weights.paymentHistory;
  const loansScore = ((5 - data.existingLoans) / 5) * weights.existingLoans;
  const historyScore = Math.min((data.creditHistory / 7) * weights.creditHistory, weights.creditHistory);

  // Calculate total score (0-100)
  const totalScore = Math.round(
    incomeScore + employmentScore + utilizationScore + paymentScore + loansScore + historyScore
  );

  // Determine risk level and recommendation
  let risk: 'Low' | 'Medium' | 'High';
  let recommendation: string;

  if (totalScore >= 80) {
    risk = 'Low';
    recommendation = 'Excellent credit score. Eligible for premium financial products with best rates.';
  } else if (totalScore >= 60) {
    risk = 'Medium';
    recommendation = 'Good credit score. Most financial products available but may not qualify for best rates.';
  } else {
    risk = 'High';
    recommendation = 'Credit score needs improvement. Focus on payment history and reducing credit utilization.';
  }

  return {
    score: totalScore,
    risk,
    recommendation,
  };
}