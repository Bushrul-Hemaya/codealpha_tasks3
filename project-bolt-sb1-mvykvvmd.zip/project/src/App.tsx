import React, { useState } from 'react';
import { FinancialData, CreditScore } from './types';
import { calculateCreditScore } from './utils/creditScoring';
import { AlertCircle, TrendingUp, BadgeCheck } from 'lucide-react';

function App() {
  const [financialData, setFinancialData] = useState<FinancialData>({
    income: 50000,
    employmentYears: 2,
    creditUtilization: 30,
    paymentHistory: 95,
    existingLoans: 1,
    creditHistory: 3,
  });

  const [creditScore, setCreditScore] = useState<CreditScore | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFinancialData(prev => ({
      ...prev,
      [name]: parseFloat(value),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const score = calculateCreditScore(financialData);
    setCreditScore(score);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <TrendingUp className="mx-auto h-12 w-12 text-blue-600" />
          <h1 className="mt-3 text-3xl font-extrabold text-gray-900">Credit Score Calculator</h1>
          <p className="mt-2 text-gray-600">Enter your financial information to calculate your credit score</p>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700">Annual Income ($)</label>
                <input
                  type="number"
                  name="income"
                  value={financialData.income}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Years Employed</label>
                <input
                  type="number"
                  name="employmentYears"
                  value={financialData.employmentYears}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Credit Utilization (%)</label>
                <input
                  type="number"
                  name="creditUtilization"
                  value={financialData.creditUtilization}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Payment History (%)</label>
                <input
                  type="number"
                  name="paymentHistory"
                  value={financialData.paymentHistory}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Number of Existing Loans</label>
                <input
                  type="number"
                  name="existingLoans"
                  value={financialData.existingLoans}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Credit History (years)</label>
                <input
                  type="number"
                  name="creditHistory"
                  value={financialData.creditHistory}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="flex justify-center">
              <button
                type="submit"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Calculate Score
              </button>
            </div>
          </form>

          {creditScore && (
            <div className="mt-8 p-6 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900">Credit Score Results</h2>
                {creditScore.risk === 'Low' && <BadgeCheck className="h-6 w-6 text-green-500" />}
                {creditScore.risk === 'Medium' && <AlertCircle className="h-6 w-6 text-yellow-500" />}
                {creditScore.risk === 'High' && <AlertCircle className="h-6 w-6 text-red-500" />}
              </div>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700">Score</span>
                    <span className="text-lg font-semibold">{creditScore.score}/100</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${
                        creditScore.risk === 'Low' 
                          ? 'bg-green-500' 
                          : creditScore.risk === 'Medium' 
                          ? 'bg-yellow-500' 
                          : 'bg-red-500'
                      }`}
                      style={{ width: `${creditScore.score}%` }}
                    ></div>
                  </div>
                </div>

                <div>
                  <span className="text-sm font-medium text-gray-700">Risk Level</span>
                  <p className={`mt-1 text-lg font-semibold ${
                    creditScore.risk === 'Low' 
                      ? 'text-green-600' 
                      : creditScore.risk === 'Medium' 
                      ? 'text-yellow-600' 
                      : 'text-red-600'
                  }`}>
                    {creditScore.risk}
                  </p>
                </div>

                <div>
                  <span className="text-sm font-medium text-gray-700">Recommendation</span>
                  <p className="mt-1 text-gray-600">{creditScore.recommendation}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;