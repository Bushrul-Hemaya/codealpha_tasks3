export interface FinancialData {
  income: number;
  employmentYears: number;
  creditUtilization: number;
  paymentHistory: number; // percentage of on-time payments
  existingLoans: number;
  creditHistory: number; // in years
}

export interface CreditScore {
  score: number;
  risk: 'Low' | 'Medium' | 'High';
  recommendation: string;
}